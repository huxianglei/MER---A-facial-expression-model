from torch import nn
import torch
from networks import MixedFeatureNet
from torch.nn import Module
import os
import torch.nn.functional as F
# from networks import scsa
# from networks import ema
from networks import ela


class CBAM(nn.Module):
    def __init__(self, channels, reduction=16, kernel_size=7):
        super(CBAM, self).__init__()
        # 通道注意力机制
        self.channel_attention = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, channels // reduction, kernel_size=1, bias=False),
            nn.ReLU(),
            nn.Conv2d(channels // reduction, channels, kernel_size=1, bias=False),
            nn.Sigmoid()
        )
        # 空间注意力机制
        self.spatial_attention = nn.Sequential(
            nn.Conv2d(2, 1, kernel_size=kernel_size, stride=1, padding=(kernel_size // 2), bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        # 通道注意力
        ca = self.channel_attention(x) * x
        # 空间注意力
        sa = self.spatial_attention(torch.cat([torch.max(ca, 1, keepdim=True)[0], torch.mean(ca, 1, keepdim=True)], dim=1)) * ca
        return sa
class DepthwiseSeparableConv(nn.Module):
    def __init__(self, in_ch, out_ch, stride=1):
        super(DepthwiseSeparableConv, self).__init__()
        self.depthwise = nn.Conv2d(in_ch, in_ch, kernel_size=3, stride=stride, padding=1, groups=in_ch, bias=False)
        self.pointwise = nn.Conv2d(in_ch, out_ch, kernel_size=1, stride=1, padding=0, bias=False)

    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        return x
class MultiScaleAtrousConv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(MultiScaleAtrousConv, self).__init__()
        self.conv1 = nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, dilation=1)  # 普通卷积
        self.conv2 = nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=2, dilation=2)  # 膨胀卷积，膨胀率=2
        self.conv3 = nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=4, dilation=4)  # 膨胀卷积，膨胀率=4
        self.fuse = nn.Conv2d(out_ch * 3, out_ch, kernel_size=1)  # 融合多尺度特征

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.conv2(x)
        x3 = self.conv3(x)
        out = torch.cat([x1, x2, x3], dim=1)  # 在通道维度上拼接
        return self.fuse(out)
class ECA(nn.Module):
    def __init__(self, channels, gamma=2, b=1):
        super(ECA, self).__init__()
        # 自适应卷积核大小（与通道数相关）
        kernel_size = int(abs((torch.log2(torch.tensor(channels)) + b) / gamma))
        kernel_size = kernel_size if kernel_size % 2 else kernel_size + 1
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.avg_pool(x)  # 全局平均池化
        y = self.conv(y.squeeze(-1).transpose(-1, -2))  # 1D卷积
        y = self.sigmoid(y.transpose(-1, -2).unsqueeze(-1))
        return x * y.expand_as(x)  # 注意力加权
class ResidualBlock(nn.Module):
    def __init__(self, in_ch, out_ch, stride=1):
        super(ResidualBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_ch, out_ch, kernel_size=3, stride=stride, padding=1)

        self.bn1 = nn.BatchNorm2d(out_ch)
        self.conv2 = nn.Conv2d(out_ch, out_ch, kernel_size=3, stride=1, padding=1)

        self.bn2 = nn.BatchNorm2d(out_ch)
        # self.elaatt= ela.EfficientLocalizationAttention(out_ch)
        # self.CoordAtt = CoordAtt(out_ch, out_ch)
        # self.deep_conv = nn.Conv2d(out_ch, out_ch, kernel_size=3, padding=1, bias=False)
        # self.shallow_conv = nn.Conv2d(out_ch, out_ch, kernel_size=1, padding=0, bias=False)

        # self.multi_scale = MultiScaleAtrousConv(out_ch, out_ch)
        # self.cbam = CBAM(out_ch, reduction=16, kernel_size=7)
        # self.eca = ECA(out_ch)  # 替换 CBAM
        # self.shortcut = nn.Sequential()
        if stride != 1 or in_ch != out_ch:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, kernel_size=1, stride=stride, padding=0),
                nn.BatchNorm2d(out_ch)
            )
        # self.global_avg_pool = nn.AdaptiveAvgPool2d(1)  # 全局平均池化
        # self.fc1 = nn.Linear(out_ch, out_ch // 16)  # 降维
        # self.fc2 = nn.Linear(out_ch // 16, out_ch)  # 升维
        # self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # residual = self.shortcut(x)
        # out = F.relu(self.bn1(self.conv1(x)))
        # out = self.bn2(self.conv2(out))
        #
        # # 通道注意力模块
        # se = self.global_avg_pool(out).view(out.size(0), -1)  # 全局平均池化并展开
        # se = F.relu(self.fc1(se))
        # se = self.sigmoid(self.fc2(se)).view(out.size(0), out.size(1), 1, 1)  # 恢复维度
        # out = out * se  # 加权
        #
        # out += residual
        # out = F.relu(out)
        out = F.relu(self.bn1(self.conv1(x)))

        # out_deep = self.deep_conv(out)
        # out_shallow = self.shallow_conv(out)
        # out = out_deep + out_shallow

        out = self.bn2(self.conv2(out))
        # out = self.multi_scale(out)
        # out = self.cbam(out)
        # out = self.eca(out)
        out += self.shortcut(x)
        out = F.relu(out)
        return out
class eca_layer(nn.Module):
    def __init__(self, channel, k_size=3):
        super(eca_layer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
        y = self.sigmoid(y)
        return x * y.expand_as(x)
class Linear_block(Module):
    def __init__(self, in_c, out_c, kernel=(1, 1), stride=(1, 1), padding=(0, 0), groups=1):
        super(Linear_block, self).__init__()
        self.conv = nn.Conv2d(in_c, out_channels=out_c, kernel_size=kernel, groups=groups, stride=stride, padding=padding, bias=False)
        self.bn = nn.BatchNorm2d(out_c)
    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        return x

class Flatten(Module):
    def forward(self, input):
        return input.view(input.size(0), -1)
nt = torch.load(os.path.join('./pretrained/', "MFN_msceleb.pth"))
pretrained_dict = nt.state_dict()
class MERNet(nn.Module):
    def __init__(self, num_class=7,num_head=2, pretrained=True, dt=pretrained_dict):
        super(MERNet, self).__init__()
        net = MixedFeatureNet.MixedFeatureNet()
        if pretrained:
            # net = torch.load(os.path.join('./pretrained/', "MFN_msceleb.pth"))
            model_dict = net.state_dict()
            dt = {k: v for k, v in dt.items() if k in model_dict}
            model_dict.update(dt)
            net.load_state_dict(model_dict)
      
        self.features = nn.Sequential(*list(net.children())[:-4])
        # self.features = model
        self.num_head = num_head
        for i in range(int(num_head)):
            setattr(self,"cat_head%d" %(i), CoordAttHead())                  
      
        self.Linear = Linear_block(512, 512, groups=512, kernel=(7, 7), stride=(1, 1), padding=(0, 0))
        self.flatten = Flatten()      
        self.fc = nn.Linear(512, num_class)
        self.bn = nn.BatchNorm1d(num_class)

        self.resnet = ResidualBlock(512,512)
        self.resnet1 = ResidualBlock(512, 1024, stride=2)
        self.resnet2 = ResidualBlock(1024, 2048, stride=2)
        self.fc1 = nn.Linear(2048, 1024)
        self.fc2 = nn.Linear(1024, 512)
        self.dropout = nn.Dropout(0.5)
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc3 = nn.Linear(512, 7)

        # self.scsaat = scsa.SCSA(dim=512, head_num=8, window_size=7)
        
    def forward(self, x):
        x = self.features(x)     #MFN
        # x = self.features.forward_feature(x)
        heads = []
       
        for i in range(self.num_head):
            heads.append(getattr(self,"cat_head%d" %i)(x))      #attention
        head_out =heads
        
        y = heads[0]
        
        for i in range(1,self.num_head):
            y = torch.max(y,heads[i])                     
        
        y = x*y

        # y = self.resnet(y)

        y = self.resnet1(y)
        # y = self.resnet2(y)
        y = self.pool(y)
        y = y.view(y.size(0), -1)
        # y = F.relu(self.fc1(y))
        # y = self.dropout(y)
        y = F.relu(self.fc2(y))
        y = self.dropout(y)
        out = self.fc(y)


        # y = self.Linear(y)
        # y = self.flatten(y)
        # out = self.fc(y)
        return out, x, head_out
        
class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)
    def forward(self, x):
        return self.relu(x + 3) / 6
                      
class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super(h_swish, self).__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)
    def forward(self, x):
        return x * self.sigmoid(x)

class CoordAttHead(nn.Module):
    def __init__(self):
        super().__init__()
        # self.CoordAtt = CoordAtt(512,512)
        # self.CoordAtt = scsa.SCSA(dim=512,head_num=8,window_size=7)
        # self.CoordAtt = ema.EMA(512)
        self.CoordAtt = ela.EfficientLocalizationAttention(512)
    def forward(self, x):
        ca = self.CoordAtt(x)
        return ca  
class SEBlock(nn.Module):
    def __init__(self, in_channels, reduction=16):
        super(SEBlock, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(in_channels, in_channels // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(in_channels // reduction, in_channels, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)
class CoordAtt(nn.Module):
    def __init__(self, inp, oup, groups=32):
        super(CoordAtt, self).__init__()
      
        self.Linear_h = Linear_block(inp, inp, groups=inp, kernel=(1, 7), stride=(1, 1), padding=(0, 0))        
        self.Linear_w = Linear_block(inp, inp, groups=inp, kernel=(7, 1), stride=(1, 1), padding=(0, 0))
        
        mip = max(8, inp // groups)

        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.conv2 = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.conv3 = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.relu = h_swish()
        self.Linear = Linear_block(oup, oup, groups=oup, kernel=(7, 7), stride=(1, 1), padding=(0, 0))
        self.flatten = Flatten()

        self.x_max_pool = nn.AdaptiveMaxPool2d((7, 1))  # 针对 x 方向的最大池化
        self.y_max_pool = nn.AdaptiveMaxPool2d((1, 7))  # 针对 y 方向的最大池化
        self.x_avg_pool = nn.AdaptiveAvgPool2d((7, 1))  # 针对 x 方向的平均池化
        self.y_avg_pool = nn.AdaptiveAvgPool2d((1, 7))  # 针对 y 方向的平均池化

    def forward(self, x):
        identity = x
        n,c,h,w = x.size()
        x_h = self.Linear_h(x)
        x_w = self.Linear_w(x)
        x_w = x_w.permute(0, 1, 3, 2)

        # x 和 y 方向的池化操作
        # x_max = self.x_max_pool(x)
        # y_max = self.y_max_pool(x)
        # x_avg = self.x_avg_pool(x_max)
        # y_avg = self.y_avg_pool(y_max)
        # y_avg = y_avg.permute(0, 1, 3, 2)
        # y = torch.cat([x_avg, y_avg], dim=2)

        y = torch.cat([x_h, x_w], dim=2)
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.relu(y) 
        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)

        x_h = self.conv2(x_h).sigmoid()
        x_w = self.conv3(x_w).sigmoid()
        x_h = x_h.expand(-1, -1, h, w)
        x_w = x_w.expand(-1, -1, h, w)
        
        y = x_w * x_h
 
        return y
